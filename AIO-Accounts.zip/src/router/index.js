import Vue from 'vue'
import Router from 'vue-router'
import getWxLogin from '../utils/authorization'
import {projectConfig} from '@/utils/projectConfig'
// import commonJS from '@/utils/common'

import {httpClient} from '@/utils/httpClient'

Vue.use(Router)

const router = new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'home',
      meta: {
        title: '聚点商城',
        keepAlive: true,
        requireArth: true
      },
      component: resolve => require(['../views/Home/index'],resolve)
    },
    {
      path: '/mine',
      name: 'mine',
      meta: {
        title: '我的',
        keepAlive: false,
        requireArth: true
      },
      component: resolve => require(['../views/Mine/index'],resolve)
    },
    {
      path: '/register',
      name: 'register',
      meta: {
        title: '注册',
        keepAlive: false,
        requireArth: false
      },
      component: resolve => require(['../views/Register/index'],resolve)
    },
    {
      path: '/detail',
      name: 'detail',
      meta: {
        title: '注册',
        keepAlive: false,
        requireArth: false
      },
      component: resolve => require(['../views/Detail/index'],resolve)
    }
  ]
})

//进行登录拦截
router.beforeEach((to, from, next) => {
   console.log(to)
  if(to.meta.requireArth&&to.name!='register'){
    var token = window.localStorage.getItem('token');
    if(token){ 
        next();
    } else {
      console.log(to.query.openid);
      if(!to.query.openid){
        console.log('跳转授权===');
        getWxLogin.request(projectConfig.WECHAT_LOGIN,'','get')
      }else{
        // 获取用户信息
        httpClient.request(projectConfig.GET_USERINFO,{openid:to.query.openid}, 'get')
        .then(res => {
          // window.localStorage.setItem('userInfo',res.data)
          next()
        })
        // next()
      }

    }
  }else{
    next()
  }
  
})

export default router;
